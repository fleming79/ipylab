# Copyright (c) IPython Development Team.
# Distributed under the terms of the Modified BSD License.

from __future__ import annotations

import asyncio
import atexit
import builtins
import contextlib
import contextvars
import getpass
import logging
import os
import signal
import sys
import threading
import time
import traceback
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar, Literal, Self

import anyio
import anyio.to_thread
import sniffio
import zmq
from IPython.core.completer import provisionalcompleter as _provisionalcompleter
from IPython.core.completer import rectify_completions as _rectify_completions
from IPython.core.error import StdinNotImplementedError
from IPython.utils.tokenutil import token_at_cursor
from jupyter_client.connect import ConnectionFileMixin
from jupyter_client.session import Session
from jupyter_core.paths import jupyter_runtime_dir
from traitlets import Bool, Container, Dict, DottedObjectName, Enum, Instance, Set, Tuple, Type, default, import_item
from zmq import Context, Flag, PollEvent, Socket, SocketOption, SocketType

from async_kernel import _version, utils
from async_kernel.asyncshell import AsyncInteractiveShell, KernelInterruptError
from async_kernel.debugger import Debugger
from async_kernel.kernelspec import KernelName
from async_kernel.thread_caller import ThreadCaller
from async_kernel.typing import ExecuteContent, ExecuteJobInfo, ExecuteMode, MsgRequest, MsgType, SocketID, null

if TYPE_CHECKING:
    from collections.abc import Callable
    from types import CoroutineType, FrameType

    from anyio.abc import TaskStatus
    from IPython.core.interactiveshell import ExecutionResult

    from async_kernel.comm import CommManager
    from async_kernel.iostream import OutStream


__all__ = ["Kernel"]


class Kernel(ConnectionFileMixin):
    """An async kernel with an anyio backend providing an IPython InteractiveShell with zmq.

    To start the kernel.

    Direct

    ``` python
    Kernel.start()
    ```

    Inside an already running asycio context.

    ``` python
    kernel = Kernel()
    async with kernel.start_in_context():
        await anyio.sleep_forever()
    ```

    """

    _job_var: ClassVar[contextvars.ContextVar[MsgRequest]] = contextvars.ContextVar("job")
    _instance: Self | None = None
    _interrupt_requested = False
    _last_interrupt_frame = None
    _stop_event = Instance(threading.Event, ())
    _stop_on_error_time: float = 0
    _interrupt_events: Container[set[threading.Event]] = Set()
    _sockets: Dict[SocketID, zmq.Socket] = Dict()
    _shell_handlers = Dict()
    _control_handlers = Dict()
    debugger = Instance(Debugger, ())
    anyio_backend = Enum(anyio.get_all_backends())

    quiet = Bool(True, help="Only send stdout/stderr to output stream").tag(config=True)
    outstream_class = DottedObjectName(
        "async_kernel.iostream.OutStream",
        help="The importstring for the OutStream factory",
        allow_none=True,
    ).tag(
        config=True,
    )
    displayhook_class = DottedObjectName(
        "async_kernel.displayhook.ZMQDisplayHook", help="The importstring for the DisplayHook factory"
    ).tag(config=True)

    session = Instance(Session)

    log = Instance(logging.LoggerAdapter)

    shell = Instance(AsyncInteractiveShell)
    shell_class = Type(AsyncInteractiveShell)
    help_links = Tuple()
    comm_manager: Instance[CommManager] = Instance("async_kernel.comm.CommManager")

    def __new__(cls, *, connection_file="", kernel_name: KernelName | None = None, **kwargs) -> Self:  # noqa: ARG004
        #  There is only one instance.
        if not (instance := cls._instance):
            cls._instance = instance = super().__new__(cls)
        return instance

    def __init__(self, *, connection_file="", kernel_name: KernelName | None = None, **kwargs):
        """Initialize the kernel."""
        if self._shell_handlers:
            return  # Only initialize once
        if kernel_name:
            self.kernel_name = kernel_name
        self.connection_file = str(connection_file)
        super().__init__(**kwargs)
        self._shell_handlers = {
            MsgType.kernel_info_request: self.kernel_info_request,
            MsgType.comm_info_request: self.comm_info_request,
            MsgType.interrupt_request: self.interrupt_request,
            MsgType.complete_request: self.complete_request,
            MsgType.is_complete_request: self.is_complete_request,
            MsgType.inspect_request: self.inspect_request,
            MsgType.history_request: self.history_request,
            MsgType.comm_open: self.comm_open,
            MsgType.comm_msg: self.comm_msg,
            MsgType.comm_close: self.comm_close,
        }
        self._control_handlers = self._shell_handlers | {
            MsgType.shutdown_request: self.control_shutdown_request,
            MsgType.debug_request: self.debug_request,
        }
        sys.excepthook = self.excepthook
        sys.unraisablehook = self.unraisablehook
        signal.signal(signal.SIGINT, self._signal_handler)
        if not os.environ.get("MPLBACKEND"):
            os.environ["MPLBACKEND"] = "module://matplotlib_inline.backend_inline"

    @property
    def job(self):
        "The job in context of the current coroutine."
        return self._job_var.get()

    @property
    def kernel_info(self):
        return {
            "protocol_version": _version.kernel_protocol_version,
            "implementation": "async_kernel",
            "implementation_version": _version.__version__,
            "language_info": _version.language_info,
            "banner": self.shell.banner,
            "help_links": self.help_links,
            "debugger": not utils.LAUNCHED_BY_DEBUGPY,
            "kernel_name": self.kernel_name,
        }

    @default("help_links")
    def _default_help_links(self):
        return (
            {
                "text": "Async Kernel Reference ",
                "url": "TODO",
            },
            {
                "text": "IPython Reference",
                "url": "https://ipython.readthedocs.io/en/stable/",
            },
            {
                "text": "IPython magic Reference",
                "url": "https://ipython.readthedocs.io/en/stable/interactive/magics.html",
            },
            {
                "text": "Matplotlib ipympl Reference",
                "url": "https://matplotlib.org/ipympl/",
            },
            {
                "text": "Matplotlib Reference",
                "url": "https://matplotlib.org/contents.html",
            },
        )

    @default("log")
    def _default_log(self):
        return logging.LoggerAdapter(logging.getLogger(self.__class__.__name__))

    @default("kernel_name")
    def _default_kernel_name(self):
        if sniffio.current_async_library() == "trio":
            return KernelName.trio
        if sys.version_info >= (3, 12) and asyncio.get_running_loop().get_task_factory() is asyncio.eager_task_factory:
            return KernelName.asyncio_eager
        return KernelName.asyncio

    @default("comm_manager")
    def _default_comm_manager(self):
        from async_kernel import comm  # noqa: PLC0415

        comm.set_comm()
        return comm.get_comm_manager()

    @default("session")
    def _default_session(self):
        return Session(parent=self)

    @default("shell")
    def _default_shell(self):
        return self.shell_class.instance(parent=self, kernel=self)

    @classmethod
    def start(cls, connection_file="", kernel_name=KernelName.asyncio) -> int:
        """Start the kernel."""

        async def _start() -> None:
            async with kernel.start_in_context():
                with contextlib.suppress(kernel.CancelledError):
                    await anyio.sleep_forever()

        kernel = cls(kernel_name=kernel_name, connection_file=connection_file)
        try:
            anyio.run(_start, backend="trio" if kernel.kernel_name is KernelName.trio else "asyncio")
        except KeyboardInterrupt:
            print("\nKernel stopped")
        except kernel.CancelledError as e:
            if not kernel._stop_event.is_set():
                e.add_note("Unexpected cancellation caused shutdown")
                raise
            return 0
        return 0

    @classmethod
    def stop(cls):
        """Stop the kernel."""
        if instance := cls._instance:
            cls._instance = None
            instance._stop_event.set()

    @asynccontextmanager
    async def start_in_context(self):
        """Start the Kernel in an already running anyio event loop."""
        if self._sockets:
            msg = "Already started"
            raise RuntimeError(msg)
        self.CancelledError = anyio.get_cancelled_exc_class()
        self.anyio_backend = sniffio.current_async_library()
        if sys.version_info >= (3, 12) and self.kernel_name is KernelName.asyncio_eager:
            loop = asyncio.get_running_loop()
            loop.set_task_factory(asyncio.eager_task_factory)
        if self.connection_file and Path(self.connection_file).exists():
            self.load_connection_file()
        try:
            async with ThreadCaller(log=self.log) as tc:
                self.main_thread_caller, tg = tc, tc.taskgroup
                try:
                    await tg.start(self._start_heartbeat)
                    await tg.start(self._start_stdin)
                    await tg.start(self._start_iopub_proxy)
                    await tg.start(self._start_control_loop)
                    await tg.start(self._shell_execute_request_loop)
                    await tg.start(self._receive_msg_loop, SocketID.shell)
                    assert len(self._sockets) == len(SocketID)
                    if not self.connection_file:
                        self.connection_file = str(Path(jupyter_runtime_dir()).joinpath(f"kernel-{uuid.uuid4()}.json"))
                    self.write_connection_file()
                    atexit.register(self.cleanup_connection_file)
                    await tg.start(self._wait_stopped)
                    print(f"""Kernel started. To connect a client use: --existing "{self.connection_file}" """)
                    await tg.start(self._start_iopub)
                    yield self
                finally:
                    self.stop()
        finally:
            Context.instance().term()

    def _signal_handler(self, signum, frame: FrameType | None):
        "Handle interrupt signals."
        if self._interrupt_requested:
            self._interrupt_requested = False
            if frame and frame.f_locals is self.shell.user_ns:
                raise KernelInterruptError
            if self._last_interrupt_frame is frame:
                # A blocking call that is not an execute_request
                raise KernelInterruptError

            self._last_interrupt_frame = frame
        else:
            signal.default_int_handler(signum, frame)

    async def _start_heartbeat(self, task_status: TaskStatus):
        # Reference: https://jupyter-client.readthedocs.io/en/stable/messaging.html#heartbeat-for-kernels

        def heartbeat():
            socket: Socket = Context.instance().socket(zmq.ROUTER)
            with utils.do_not_debug_this_thread("heartbeat"), self._bind_socket(SocketID.heartbeat, socket):
                ready_event.set()
                try:
                    zmq.proxy(socket, socket)
                except zmq.ContextTerminated:
                    return

        ready_event = threading.Event()
        heartbeat_thread = threading.Thread(target=heartbeat, daemon=True)
        heartbeat_thread.start()
        ready_event.wait(10)
        task_status.started()

    async def _start_stdin(self, task_status: TaskStatus):
        socket = Context.instance().socket(SocketType.ROUTER)
        socket.linger = 0
        with self._bind_socket(SocketID.stdin, socket), contextlib.suppress(self.CancelledError):
            task_status.started()
            await anyio.sleep_forever()

    async def _start_iopub_proxy(self, task_status: TaskStatus):
        """Provide an io proxy"""

        def pub_proxy():
            # We use an internal proxy to collect pub messages for distribution.
            # Each thread needs to open its own socket to publish to the internal proxy.
            # When thread-safe sockets become available, this could be changed...
            # which could come from any thread in this process.
            # Ref: https://zguide.zeromq.org/docs/chapter2/#Working-with-Messages (fig 14)
            frontend: zmq.Socket = Context.instance().socket(zmq.XSUB)
            frontend.bind(ThreadCaller.iopub_url)
            iopub_socket: zmq.Socket = Context.instance().socket(zmq.XPUB)
            with utils.do_not_debug_this_thread("iopub"), self._bind_socket(SocketID.iopub, iopub_socket):
                ready_event.set()
                try:
                    zmq.proxy(frontend, iopub_socket)
                except zmq.ContextTerminated:
                    frontend.close(linger=500)

        ready_event = threading.Event()
        iopub_thread = threading.Thread(target=pub_proxy, name="iopub proxy", daemon=True)
        iopub_thread.start()
        ready_event.wait(10)
        task_status.started()

    async def _start_control_loop(self, task_status: TaskStatus):
        async def run_in_control_event_loop():
            await tsc.taskgroup.start(self._receive_msg_loop, SocketID.control)
            ready_event.set()

        self.control_thread_caller = tsc = ThreadCaller.start_new(backend=self.anyio_backend, name="Control")
        ready_event = threading.Event()
        tsc.call_soon(run_in_control_event_loop)
        ready_event.wait(10)
        task_status.started()

    async def _start_iopub(self, task_status: TaskStatus):
        # Save IO
        self._original_io = sys.stdout, sys.stderr, sys.displayhook, builtins.input, self.getpass
        cls: type[OutStream] = import_item(self.outstream_class)
        if self.outstream_class:
            builtins.input = self.raw_input
            getpass.getpass = self.getpass
            for name in ["stdout", "stderr"]:

                def flusher(string: str, name=name):
                    "Publish stdio or stderr when flush is called"
                    self.iopub_send(
                        msg_or_type="stream",
                        content={"name": name, "text": string},
                        ident=f"stream.{name}".encode(),
                    )
                    if not self.quiet and (echo := (sys.__stdout__ if name == "stdout" else sys.__stderr__)):
                        echo.write(string)
                        echo.flush()

                wrapper = cls(name=name, flusher=flusher)  # type: ignore[call-arg]
                setattr(sys, name, wrapper)
        task_status.started()
        self.comm_manager.kernel = self
        try:
            await anyio.sleep_forever()
        except self.CancelledError:
            return
        finally:
            self.comm_manager.kernel = None
            # Reset IO
            sys.stdout, sys.stderr, sys.displayhook, builtins.input, getpass.getpass = self._original_io

    async def _wait_stopped(self, task_status: TaskStatus):
        task_status.started()
        try:
            await utils.wait_thread_event(self._stop_event)
        except BaseException:
            pass
        self.control_thread_caller.close()
        self.main_thread_caller.close()
        ThreadCaller._shutdown_to_thread_instances()

    async def _receive_msg_loop(self, socket_id: Literal[SocketID.control, SocketID.shell], *, task_status: TaskStatus):
        """Receive messages from the socket, unpack them and pass them to be processed with process_message."""
        if (
            sys.platform == "win32"
            and sniffio.current_async_library() == "asyncio"
            and (policy := asyncio.get_event_loop_policy())
            and policy.__class__.__name__ == "WindowsProactorEventLoopPolicy"
        ):
            from anyio._core._asyncio_selector_thread import get_selector  # noqa: PLC0415

            selector = get_selector()
            utils.mark_thread_pydev_do_not_trace(selector._thread)
        socket: Socket = Context.instance().socket(SocketType.ROUTER)
        with self._bind_socket(socket_id, socket):
            try:
                task_status.started()
                while True:
                    while socket.get(SocketOption.EVENTS) & PollEvent.POLLIN:  # type: ignore[call-arg]
                        ident, parent = self.session.recv(socket, copy=False)
                        if socket_id == SocketID.shell:
                            # Reset the frame to show the main thread is not blocked.
                            self._last_interrupt_frame = None
                        if not ident or not parent:
                            continue
                        msg_type = parent["header"]["msg_type"]
                        self.log.debug("*** _receive_msg_loop %s*** '%s' %s", socket_id, msg_type, parent["content"])
                        job = MsgRequest(
                            socket_id=socket_id,
                            socket=socket,
                            ident=ident,
                            parent=parent,  # type: ignore[call-arg]
                            msg_type=msg_type,
                        )
                        if msg_type == MsgType.execute_request:
                            info = utils.get_execute_info(parent["content"])
                            if socket_id != SocketID.shell or info["execute_mode"] != ExecuteMode.queue:
                                ThreadCaller().call_soon(self.execute_request, time.monotonic(), job, info)
                            else:
                                await self._exec_send_stream.send((time.monotonic(), job, info))
                        else:
                            hdlrs = self._shell_handlers if socket_id == SocketID.shell else self._control_handlers
                            await self._run_handler(hdlrs.get(msg_type), job)
                    await anyio.wait_readable(socket)
            except (zmq.ContextTerminated, self.CancelledError):
                return

    async def _run_handler(self, handler: Callable[[MsgRequest], CoroutineType] | None, job: MsgRequest):
        self._job_var.set(job)
        if not handler:
            self.log.error("Unknown message type: %r", job["msg_type"])
            return
        try:
            self._publish_status("busy", job)
            await handler(job)
        except Exception as e:
            self._send_error_reply(job, ename=str(type(e).__name__), evalue=str(e), traceback=traceback.format_stack())
            self.log.exception("Exception in message handler:", exc_info=e)
        finally:
            self._publish_status("idle", job)

    @contextlib.contextmanager
    def _bind_socket(self, socket_id: SocketID, socket: zmq.Socket):
        """Bind a zmq.Socket storing a reference to the socket and the port
        details and closing the socket on leaving the context."""
        if socket_id in self._sockets:
            msg = f"{socket_id=} is already loaded"
            raise RuntimeError(msg)
        socket.linger = 500
        port_name = f"{socket_id}_port"
        if socket_id is not SocketID.iopub:
            # ref: https://github.com/ipython/ipykernel/issues/270
            socket.router_handover = 1
        port = utils.bind_socket(socket=socket, transport=self.transport, ip=self.ip, port=getattr(self, port_name))  # type: ignore[call-arg]
        setattr(self, port_name, port)
        self.log.debug("%s socket on port: %i", socket_id, port)
        self._sockets[socket_id] = socket
        try:
            yield
        finally:
            socket.close(linger=500)
            self._sockets.pop(socket_id)

    def iopub_send(
        self,
        msg_or_type: dict[str, Any] | str,
        content: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        parent: dict[str, Any] | None | null = null,
        ident: bytes | list[bytes] | None = None,
        buffers: list[bytes] | None = None,
    ):
        """Send a message on the zmq iopub socket."""
        if socket := ThreadCaller.iopub_sockets.get(thread := threading.current_thread()):
            msg = self.session.send(
                stream=socket,
                msg_or_type=msg_or_type,
                content=content,
                metadata=metadata,
                parent=parent if parent is not null else self.job.get("parent"),  # type: ignore[call-arg]
                ident=ident,
                buffers=buffers,
            )
            if msg:
                self.log.debug(
                    "iopub_send: (thread=%s) msg_type:'%s', content: %s", thread.name, msg["msg_type"], msg["content"]
                )
        else:
            self.control_thread_caller.call_later(
                self.iopub_send,
                msg_or_type=msg_or_type,
                content=content,
                metadata=metadata,
                parent=parent,
                ident=ident,
                buffers=buffers,
            )

    def _publish_status(self, status: Literal["busy", "idle"], job: MsgRequest):
        """send status (busy/idle) on IOPub"""
        self.iopub_send(
            msg_or_type="status",
            content={"execution_state": status},
            parent=job["parent"],  # type: ignore[call-arg]
            ident=self._topic("status"),
        )

    def send_reply(self, job: MsgRequest, content: dict | None = None):
        content = content or {}
        if "status" not in content:
            content["status"] = "ok"
        msg = self.session.send(
            stream=job["socket"],
            msg_or_type=job["msg_type"].replace("request", "reply"),
            content=content,
            parent=job["parent"]["header"],  # type: ignore[call-arg]
            ident=job["ident"],
        )
        if msg:
            self.log.debug(
                "send_reply: '%s' msg_id: %s %s", msg["msg_type"], job["parent"]["header"]["msg_id"], msg["content"]
            )

    def _send_error_reply(
        self, job: MsgRequest, *, ename="RuntimeError", evalue="", traceback: list[str] | None = None
    ):
        "Send a reply to the request"
        content = {
            "status": "error",
            "execution_count": self.shell.execution_count,
            "ename": ename,
            "evalue": evalue,
            "traceback": traceback or [],
        }
        self.send_reply(job, content)

    async def _shell_execute_request_loop(self, *, task_status: TaskStatus):
        self._exec_send_stream, self._exec_receive_stream = anyio.create_memory_object_stream[
            tuple[float, MsgRequest, ExecuteJobInfo]
        ](max_buffer_size=1000)
        with contextlib.suppress(self.CancelledError):
            async with self._exec_receive_stream as receive_stream:
                task_status.started()
                async for job, received_time, info in receive_stream:
                    await self.execute_request(job, received_time, info)

    def _topic(self, topic):
        """prefixed topic for IOPub messages"""
        return (f"kernel.{topic}").encode()

    def _input_request(self, prompt: str, *, password=False):
        job = self.job
        if not job["parent"].get("content", {}).get("allow_stdin", False):
            msg = "Stdin is not allowed in this context!"
            raise StdinNotImplementedError(msg)
        socket = self._sockets[SocketID.stdin]
        # Clear messages on the stdin socket
        while socket.get(SocketOption.EVENTS) & PollEvent.POLLIN:  # type: ignore[call-arg]
            socket.recv_multipart(flags=Flag.DONTWAIT, copy=False)
        # Send the input request.
        assert self is not None
        self.session.send(
            stream=socket,
            msg_or_type="input_request",
            content={"prompt": prompt, "password": password},
            parent=job["parent"],  # type: ignore[call-arg]
            ident=job["ident"],
        )
        # Poll for a reply.
        while not (socket.poll(100) & PollEvent.POLLIN):
            if self._last_interrupt_frame:
                raise KernelInterruptError
        _, reply = self.session.recv(socket)
        if reply:
            return reply["content"]["value"]
        raise ValueError

    async def kernel_info_request(self, job: MsgRequest):
        """Handle a kernel info request."""

        self.send_reply(job, self.kernel_info)

    async def comm_info_request(self, job: MsgRequest):
        """Handle a comm info request."""
        content = job["parent"]["content"]
        target_name = content.get("target_name", None)
        comms = {
            k: {"target_name": v.target_name}
            for (k, v) in tuple(self.comm_manager.comms.items())
            if v.target_name == target_name or target_name is None
        }
        self.send_reply(job, {"comms": comms})

    async def execute_request(self, received_time: float, job: MsgRequest[ExecuteContent], info: ExecuteJobInfo):
        """Perform the actual execute_request."""
        content = job["parent"]["content"].copy()
        silent = content["silent"]

        if not silent and received_time < self._stop_on_error_time:
            self.log.info("Aborting execute_request: %s", job)
            self._publish_status("busy", job)
            self._send_error_reply(job, evalue="Aborting due to prior exception")
            self._publish_status("idle", job)
            return

        async def execute_request_handler(job):
            # ref: https://jupyter-client.readthedocs.io/en/stable/messaging.html#execute

            if not silent:
                self.iopub_send(
                    msg_or_type="execute_input",
                    content={"code": content["code"], "execution_count": self.shell.execution_count},
                    parent=job["parent"],
                    ident=self._topic("execute_input"),
                )

            async def _do_execute():
                code = content["code"]
                cell_id = None if silent else job["parent"].get("metadata", {}).get("cellId")
                user_expressions = info.get("user_expressions") or content.get("user_expressions", {})
                self.shell.namespace = info["namespace"]
                interrupt = threading.Event()
                result: ExecutionResult | None = None
                if not silent:
                    self._interrupt_events.add(interrupt)
                try:

                    async def run():
                        nonlocal result
                        try:
                            result = await self.shell.run_cell_async(
                                raw_cell=code,
                                store_history=content.get("store_history", False),
                                silent=silent,
                                transformed_cell=self.shell.transform_cell(code),
                                shell_futures=True,
                                cell_id=cell_id,
                            )
                        except asyncio.CancelledError:
                            pass
                        finally:
                            interrupt.set()

                    async with anyio.create_task_group() as tg:
                        tg.start_soon(run)
                        await anyio.to_thread.run_sync(interrupt.wait)
                        if result is None:
                            tg.cancel_scope.cancel()
                finally:
                    self._interrupt_events.discard(interrupt)
                err = result.error_before_exec or result.error_in_exec if result else KernelInterruptError
                if user_expressions:
                    user_expressions = self.shell.user_expressions(user_expressions)
                reply_content = {
                    "status": "ok" if not err else "error",
                    "execution_count": self.shell.execution_count - 1,
                    "user_expressions": user_expressions,
                }
                if err:
                    reply_content.update({
                        "traceback": self.shell._last_traceback or [],
                        "ename": type(err).__name__,
                        "evalue": str(err),
                    })
                return reply_content

            stop_on_error = content.pop("stop_on_error", True)
            if info["execute_mode"] == ExecuteMode.thread:
                pr = ThreadCaller.to_thread(_do_execute)
                reply_content = await pr.wait()
            else:
                reply_content = await _do_execute()
            if not silent and stop_on_error and reply_content.get("status") == "error":
                self._stop_on_error_time = time.monotonic()
                self.log.info("An error occurred in a non-silent execution request")
            # Send the reply.
            self.send_reply(job, reply_content)

        await self._run_handler(execute_request_handler, job)

    async def interrupt_request(self, job: MsgRequest):
        """Handle an interrupt request."""
        self._interrupt_requested = True
        if sys.platform == "win32":
            signal.raise_signal(signal.SIGINT)
            time.sleep(0)
        else:
            os.kill(os.getpid(), signal.SIGINT)
        for event in tuple(self._interrupt_events):
            event.set()
        self.send_reply(job)

    async def complete_request(self, job: MsgRequest):
        """Handle a completion request."""
        parent = job["parent"]
        matches = await self.do_complete(parent["content"]["code"], parent["content"]["cursor_pos"])
        self.send_reply(job, matches)

    async def is_complete_request(self, job: MsgRequest):
        """Handle an is_complete request."""
        reply_content = await self.do_is_complete(job["parent"]["content"]["code"])
        self.send_reply(job, reply_content)

    async def inspect_request(self, job: MsgRequest):
        """Handle an inspect request."""
        content = job["parent"]["content"]
        reply_content = await self.do_inspect(
            content["code"],
            content["cursor_pos"],
            int(content.get("detail_level", 0)),
            set(content.get("omit_sections", [])),
        )
        self.send_reply(job, reply_content)

    async def history_request(self, job: MsgRequest):
        """Handle a history request."""
        reply_content = await self.do_history(**job["parent"]["content"])  # type: ignore[call-arg]
        self.send_reply(job, reply_content)

    async def comm_open(self, job: MsgRequest):
        self.comm_manager.comm_open(job["socket"], job["ident"], job["parent"])  # type: ignore[call-arg]

    async def comm_msg(self, job: MsgRequest):
        self.comm_manager.comm_msg(job["socket"], job["ident"], job["parent"])  # type: ignore[call-arg]

    async def comm_close(self, job: MsgRequest):
        self.comm_manager.comm_close(job["socket"], job["ident"], job["parent"])  # type: ignore[call-arg]

    async def control_shutdown_request(self, job: MsgRequest):
        """Handle a shutdown request."""
        await self.debugger.disconnect()
        self.send_reply(job, {"status": "ok", "restart": job["parent"]["content"].get("restart", False)})
        self.stop()

    async def debug_request(self, job: MsgRequest):
        """Handle a debug request."""
        content = await self.debugger.process_request(job["parent"]["content"])
        self.send_reply(job=job, content=content)

    async def do_complete(self, code, cursor_pos):
        """Completions from IPython, using Jedi."""
        cursor_pos = cursor_pos if cursor_pos is not None else len(code)
        with _provisionalcompleter():
            completions = list(_rectify_completions(code, self.shell.Completer.completions(code, cursor_pos)))
        comps = [
            {
                "start": comp.start,
                "end": comp.end,
                "text": comp.text,
                "type": comp.type,
                "signature": comp.signature,
            }
            for comp in completions
        ]
        if completions:
            s, e = completions[0].start, completions[0].end
            matches = [c.text for c in completions]
        else:
            s = e = cursor_pos
            matches = []
        return {
            "matches": matches,
            "cursor_end": e,
            "cursor_start": s,
            "metadata": {"_jupyter_types_experimental": comps},
            "status": "ok",
        }

    async def do_is_complete(self, code):
        """Handle an is_complete request."""
        status, indent_spaces = self.shell.input_transformer_manager.check_complete(code)
        r = {"status": status}
        if status == "incomplete":
            r["indent"] = " " * indent_spaces
        return r

    async def do_inspect(self, code, cursor_pos, detail_level=0, omit_sections=()):
        """Handle code inspection."""
        name = token_at_cursor(code, cursor_pos)

        reply_content: dict[str, Any] = {"status": "ok"}
        reply_content["data"] = {}
        reply_content["metadata"] = {}
        try:
            bundle = self.shell.object_inspect_mime(name, detail_level=detail_level, omit_sections=omit_sections)
            reply_content["data"].update(bundle)
            if not self.shell.enable_html_pager:
                reply_content["data"].pop("text/html")
            reply_content["found"] = True
        except KeyError:
            reply_content["found"] = False
        return reply_content

    async def do_history(
        self,
        hist_access_type,
        output,
        raw,
        session=0,
        start=0,
        stop=None,
        n=None,
        pattern=None,
        unique=False,
    ):
        """Handle code history."""

        history_manager = self.shell.history_manager
        assert history_manager
        if hist_access_type == "tail":
            hist = history_manager.get_tail(n, raw=raw, output=output, include_latest=True)
        elif hist_access_type == "range":
            hist = history_manager.get_range(session, start, stop, raw=raw, output=output)
        elif hist_access_type == "search":
            hist = history_manager.search(pattern, raw=raw, output=output, n=n, unique=unique)
        else:
            hist = []
        return {
            "status": "ok",
            "history": list(hist),
        }

    def excepthook(self, etype, evalue, tb):
        """Handle an exception."""
        # write uncaught traceback to 'real' stderr, not zmq-forwarder
        traceback.print_exception(etype, evalue, tb, file=sys.__stderr__)

    def unraisablehook(self, unraisable: sys.UnraisableHookArgs, /):
        "Handle unraisable exceptions (during gc for instance)."
        exc_info = (
            unraisable.exc_type,
            unraisable.exc_value or unraisable.exc_type(unraisable.err_msg),
            unraisable.exc_traceback,
        )
        self.log.exception(unraisable.err_msg, exc_info=exc_info, extra={"object": unraisable.object})

    def raw_input(self, prompt=""):
        """Forward raw_input to frontends.

        Raises
        ------
        StdinNotImplementedError if active frontend doesn't support stdin.
        """
        return self._input_request(str(prompt), password=False)

    def getpass(self, prompt=""):
        """Forward getpass to frontends."""
        return self._input_request(prompt, password=True)
