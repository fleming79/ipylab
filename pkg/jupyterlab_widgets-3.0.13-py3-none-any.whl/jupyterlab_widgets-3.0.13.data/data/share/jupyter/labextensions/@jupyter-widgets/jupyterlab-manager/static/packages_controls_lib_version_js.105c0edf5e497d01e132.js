"use strict";
(self["webpackChunk_jupyter_widgets_jupyterlab_manager"] = self["webpackChunk_jupyter_widgets_jupyterlab_manager"] || []).push([["packages_controls_lib_version_js"],{

/***/ "../../packages/controls/lib/version.js":
/*!**********************************************!*\
  !*** ../../packages/controls/lib/version.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JUPYTER_CONTROLS_VERSION: () => (/* binding */ JUPYTER_CONTROLS_VERSION)
/* harmony export */ });
// Copyright (c) Jupyter Development Team.
// Distributed under the terms of the Modified BSD License.
/**
 * The version of the Jupyter controls widget attribute spec that this package
 * implements.
 */
const JUPYTER_CONTROLS_VERSION = '2.0.0';


/***/ })

}]);
//# sourceMappingURL=packages_controls_lib_version_js.105c0edf5e497d01e132.js.map